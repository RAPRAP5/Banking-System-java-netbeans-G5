
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author THIS PC
 */
public final class admin_dashboard extends javax.swing.JFrame {

    /**
     * Creates new form Ladin_dashboard
     */
    public admin_dashboard() {
        initComponents();
        Connect();
        create_acc();
        user_info();
        deposite_histo();
        withdraw_histo();
        transfer_histo();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        
    }
        Connection con;
        PreparedStatement pst;
        ResultSet rs;
    
    public void Connect()
{
    try{
      Class.forName("com.mysql.jdbc.Driver");
        Connection Con;
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Banking_management_system","root","");
    }catch(ClassNotFoundException | SQLException ex){
        Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
    }
}
    
    
    
    private void create_acc(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM create_acc");
            rs = pst.executeQuery();
            ResultSetMetaData zz = rs.getMetaData();
            q = zz.getColumnCount();
            
            DefaultTableModel tb = (DefaultTableModel)jTable15.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                Vector v1 = new Vector();
                for(int a = 1; a<=q; a++){
                    v1.add(rs.getString("acc_id"));
                    v1.add(rs.getString("name"));
                    v1.add(rs.getString("dob"));
                    v1.add(rs.getString("nationality"));
                    v1.add(rs.getString("gender"));
                    v1.add(rs.getString("address"));
                    v1.add(rs.getString("account_no"));
                    v1.add(rs.getString("account_pin"));
                    v1.add(rs.getString("account_type"));
                    
                }
                tb.addRow(v1);
            }
            //con.close();
        } catch (SQLException ex) {
            Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    
    private void user_info(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM create_acc");
            rs = pst.executeQuery();
            ResultSetMetaData zz = rs.getMetaData();
            q = zz.getColumnCount();
            
            DefaultTableModel tb = (DefaultTableModel)jTable23.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                Vector v1 = new Vector();
                for(int a = 1; a<=q; a++){
                    v1.add(rs.getString("acc_id"));
                    v1.add(rs.getString("name"));
                    v1.add(rs.getString("account_no"));
                    v1.add(rs.getString("account_pin"));
                    v1.add(rs.getString("account_type"));
                    v1.add(rs.getString("amount_deposit"));
                   
                    
                }
                tb.addRow(v1);
            }
            //con.close();
        } catch (SQLException ex) {
            Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    
              
    
    private void deposite_histo(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM deposit_histo");
            rs = pst.executeQuery();
            ResultSetMetaData zz = rs.getMetaData();
            q = zz.getColumnCount();
            
            DefaultTableModel tb = (DefaultTableModel)jTable2.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                Vector v1 = new Vector();
                for(int a = 1; a<=q; a++){
                    v1.add(rs.getString("depo_id"));
                    v1.add(rs.getString("account_no"));
                    v1.add(rs.getString("date"));
                    v1.add(rs.getString("time"));
                    v1.add(rs.getString("amount_depo"));
                   
                    
                }
                tb.addRow(v1);
            }
            //con.close();
        } catch (SQLException ex) {
            Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    
    private void withdraw_histo(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM withdraw_histo");
            rs = pst.executeQuery();
            ResultSetMetaData zz = rs.getMetaData();
            q = zz.getColumnCount();
            
            DefaultTableModel tb = (DefaultTableModel)jTable21.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                Vector v1 = new Vector();
                for(int a = 1; a<=q; a++){
                    v1.add(rs.getString("withdraw_id"));
                    v1.add(rs.getString("account_no"));
                    v1.add(rs.getString("date"));
                    v1.add(rs.getString("time"));
                    v1.add(rs.getString("amount_withdraw"));
                   
                    
                }
                tb.addRow(v1);
            }
            //con.close();
        } catch (SQLException ex) {
            Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    
    private void transfer_histo(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM transfer_histo");
            rs = pst.executeQuery();
            ResultSetMetaData zz = rs.getMetaData();
            q = zz.getColumnCount();
            
            DefaultTableModel tb = (DefaultTableModel)jTable5.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                Vector v1 = new Vector();
                for(int a = 1; a<=q; a++){
                    v1.add(rs.getString("trans_id"));
                    v1.add(rs.getString("account_no"));
                    v1.add(rs.getString("date"));
                    v1.add(rs.getString("time"));
                    v1.add(rs.getString("amount_trans"));
                    v1.add(rs.getString("credit_amount"));
                   
                    
                }
                tb.addRow(v1);
            }
            //con.close();
        } catch (SQLException ex) {
            Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    
    private void displayBalance(String accountNumber, String accountPin) {
    try {
        
        pst = con.prepareStatement("SELECT amount_deposit FROM create_acc WHERE account_no = ? AND account_pin = ?");
        pst.setString(1, accountNumber);
        pst.setString(2, accountPin);

        rs = pst.executeQuery();

        if (rs.next()) {
            
            String balance = rs.getString("amount_deposit");
            JOptionPane.showMessageDialog(null, "Your current balance is: " + balance);
        } else {
            
            JOptionPane.showMessageDialog(null, "Invalid account number or PIN. Please try again.");
        }

    } catch (SQLException ex) {
        Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error accessing the database. Please try again later.");
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane12 = new javax.swing.JTabbedPane();
        jPanel23 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        nationalityField = new javax.swing.JTextField();
        addressField = new javax.swing.JTextField();
        nameField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        accountNoField = new javax.swing.JTextField();
        accountPinField = new javax.swing.JTextField();
        dobField = new com.toedter.calendar.JDateChooser();
        accountTypeComboBox = new javax.swing.JComboBox<>();
        jButton11 = new javax.swing.JButton();
        maleRadioButton = new javax.swing.JRadioButton();
        femaleRadioButton = new javax.swing.JRadioButton();
        jLabel21 = new javax.swing.JLabel();
        amount = new javax.swing.JTextField();
        jTabbedPane13 = new javax.swing.JTabbedPane();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTable15 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        nationality1 = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        search = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        dob = new com.toedter.calendar.JDateChooser();
        id_no = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        updateButton1 = new javax.swing.JButton();
        gender1 = new javax.swing.JComboBox<>();
        jPanel32 = new javax.swing.JPanel();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTable23 = new javax.swing.JTable();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        acc1 = new javax.swing.JTextField();
        n1 = new javax.swing.JTextField();
        pin1 = new javax.swing.JTextField();
        bal1 = new javax.swing.JTextField();
        search1 = new javax.swing.JTextField();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        id_n = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        accty1 = new javax.swing.JComboBox<>();
        jButton28 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel25 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        search81 = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jPanel30 = new javax.swing.JPanel();
        jScrollPane21 = new javax.swing.JScrollPane();
        jTable21 = new javax.swing.JTable();
        search82 = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        search83 = new javax.swing.JTextField();
        jButton14 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jPanel23.setBackground(new java.awt.Color(0, 0, 0));

        jLabel13.setBackground(new java.awt.Color(153, 51, 0));
        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("F5 MANAGEMENT SYSTEM");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 979, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(253, 253, 253)
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(278, 278, 278))
        );

        jTabbedPane12.addTab("", jPanel23);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3), "Create Account", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 36))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Nationality :");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Address :");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Name :");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Date of birth :");

        addressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressFieldActionPerformed(evt);
            }
        });

        nameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameFieldActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Gender :");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("Account no :");

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("Account Pin :");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Account Type :");

        accountNoField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                accountNoFieldKeyTyped(evt);
            }
        });

        accountPinField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accountPinFieldActionPerformed(evt);
            }
        });
        accountPinField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                accountPinFieldKeyTyped(evt);
            }
        });

        accountTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "....", "Savings Account", "NRI Account", "Joint Account", "Salary Account", "Loan Account" }));

        jButton11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton11.setText("Create");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        buttonGroup1.add(maleRadioButton);
        maleRadioButton.setText("Male");
        maleRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleRadioButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(femaleRadioButton);
        femaleRadioButton.setText("Female");
        femaleRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femaleRadioButtonActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Deposit Amount :");

        amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amountActionPerformed(evt);
            }
        });
        amount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                amountKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel8))
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nameField, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                            .addComponent(dobField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(nationalityField))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(maleRadioButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(femaleRadioButton))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(addressField)))))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(117, 117, 117)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel10Layout.createSequentialGroup()
                                                .addComponent(jLabel19)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(accountPinField, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE))
                                            .addGroup(jPanel10Layout.createSequentialGroup()
                                                .addComponent(jLabel18)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(accountNoField, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                                                .addGap(3, 3, 3))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(accountTypeComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(75, 75, 75))))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(amount)))
                        .addGap(155, 155, 155))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton11)
                        .addGap(172, 172, 172))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(44, 44, 44)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9)
                            .addComponent(dobField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(nationalityField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(67, 67, 67))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel7)
                                .addComponent(maleRadioButton)
                                .addComponent(femaleRadioButton)
                                .addComponent(jLabel21)
                                .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(accountNoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(accountPinField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(accountTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(67, 67, 67)))
                .addGap(36, 36, 36)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addressField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(201, Short.MAX_VALUE))
        );

        jTabbedPane12.addTab("", jPanel10);

        jTable15.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Name", "Date of Birth", "Nationality", "Gender", "Address"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable15MouseClicked(evt);
            }
        });
        jScrollPane15.setViewportView(jTable15);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Name:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Nationality:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Date of Birth:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Gender:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Address:");

        name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameKeyTyped(evt);
            }
        });

        nationality1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nationality1KeyTyped(evt);
            }
        });

        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton6.setText("Delete");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        updateButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton12.setText("Refresh");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        id_no.setEditable(false);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("No. :");

        updateButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        updateButton1.setText("Clear");
        updateButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButton1ActionPerformed(evt);
            }
        });

        gender1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MALE", "FEMALE" }));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updateButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                            .addComponent(id_no, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nationality1, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE))
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gender1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(89, 89, 89)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(address, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dob, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGap(97, 97, 97))
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton12)
                .addGap(32, 32, 32))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
            .addComponent(jScrollPane15, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(id_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11))
                            .addComponent(dob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nationality1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(gender1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(updateButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45))
        );

        jTabbedPane13.addTab("User Profile List", jPanel22);

        jTable23.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Name", "Account no.", "Pin", "Account type", "Balance"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable23MouseClicked(evt);
            }
        });
        jScrollPane23.setViewportView(jTable23);

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel35.setText("Account no :");

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel36.setText("Name :");

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel37.setText("Balance :");

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel38.setText("Account tType :");

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel39.setText("Pin :");

        acc1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                acc1KeyTyped(evt);
            }
        });

        n1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                n1KeyTyped(evt);
            }
        });

        pin1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pin1KeyTyped(evt);
            }
        });

        bal1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bal1KeyTyped(evt);
            }
        });

        search1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search1KeyReleased(evt);
            }
        });

        jButton18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton18.setText("Delete");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton19.setText("Update");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel40.setText("No. :");

        id_n.setEditable(false);

        jButton16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton16.setText("Refresh");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        accty1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Savings Account", "NRI Account", "Joint Account", "Salary Account", "Loan Account" }));

        jButton28.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton28.setText("Clear");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane23)
                .addContainerGap())
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(search1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton16)
                .addGap(39, 39, 39))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel36)
                            .addComponent(jLabel40))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel32Layout.createSequentialGroup()
                                .addComponent(n1, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                                .addGap(91, 91, 91)
                                .addComponent(jLabel39))
                            .addGroup(jPanel32Layout.createSequentialGroup()
                                .addComponent(id_n)
                                .addGap(142, 142, 142)
                                .addComponent(jLabel35)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(acc1)
                            .addComponent(pin1, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))
                        .addGap(106, 106, 106)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bal1, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                                .addComponent(jLabel38)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(accty1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGap(83, 83, 83))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(acc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel38)
                    .addComponent(jLabel40)
                    .addComponent(id_n, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(accty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(n1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel37)
                    .addComponent(bal1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39)
                    .addComponent(pin1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45))
        );

        jTabbedPane13.addTab("User Account Info", jPanel32);

        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jTable2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Account No.", "Date", "Time", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        search81.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search81MouseClicked(evt);
            }
        });
        search81.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search81KeyReleased(evt);
            }
        });

        jButton13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton13.setText("Delete");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton25.setText("Refresh");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(261, 261, 261)
                .addComponent(search81, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton25)
                    .addComponent(search81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Deposit", jPanel25);

        jPanel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jTable21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTable21.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Account No.", "Date", "Time", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane21.setViewportView(jTable21);

        search82.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search82KeyReleased(evt);
            }
        });

        jButton15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton15.setText("Delete");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton26.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton26.setText("Refresh");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane21)
                .addContainerGap())
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(269, 269, 269)
                .addComponent(search82, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 342, Short.MAX_VALUE)
                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Withdraw", jPanel30);

        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jTable5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Account No.", "Date", "Time", "Amount", "Credit Account No."
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(jTable5);

        search83.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search83KeyReleased(evt);
            }
        });

        jButton14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton14.setText("Delete");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton27.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton27.setText("Refresh");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 983, Short.MAX_VALUE)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(277, 277, 277)
                .addComponent(search83, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton27)
                .addGap(56, 56, 56))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(search83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton27))
                .addGap(11, 11, 11)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(128, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Transfer", jPanel29);

        jTabbedPane13.addTab("Transaction History", jTabbedPane2);

        jTabbedPane12.addTab("", jTabbedPane13);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setText("Withdraw");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setText("Deposit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setText("Transfer");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setText("Create Acc.");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton5.setText("User Info");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton20.setText("Exit");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane12)
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane12)))
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          new admin_deposit().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void addressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressFieldActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new admin_withdraw().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       new admin_transfer().setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jTabbedPane12.setSelectedIndex(1);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane12.setSelectedIndex(2);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        new admin_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void nameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameFieldActionPerformed

    private void accountPinFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accountPinFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accountPinFieldActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
try {
    String name = nameField.getText().trim();
    Date dobDate = dobField.getDate(); 
    String nationality = nationalityField.getText().trim();
    String gender = null;
    String address = addressField.getText().trim(); 
    String accountNo = accountNoField.getText().trim();
    String accountPin = accountPinField.getText().trim(); 
    String accountType = accountTypeComboBox.getSelectedItem().toString().trim();
    String amountdepo = amount.getText().trim();
    
    if (name.isEmpty() || nationality.isEmpty() || address.isEmpty() || accountNo.isEmpty() || accountPin.isEmpty() || accountType.isEmpty() || amountdepo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    if (buttonGroup1.getSelection() != null) {
        gender = buttonGroup1.getSelection().getActionCommand();
    }
    
    if (gender == null || gender.isEmpty() ) {
        JOptionPane.showMessageDialog(null, "Please select a gender.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    

    
    StringBuilder missingFields = new StringBuilder();
    if (name.isEmpty()) missingFields.append("Name\n");
    if (dobDate == null) missingFields.append("Date of Birth\n");
    if (nationality.isEmpty()) missingFields.append("Nationality\n");
    if (gender.isEmpty()) missingFields.append("Gender\n");
    if (address.isEmpty()) missingFields.append("Address\n");
    if (accountNo.isEmpty()) missingFields.append("Account Number\n");
    if (accountPin.isEmpty()) missingFields.append("Account PIN\n");
    if (accountType.isEmpty() || accountTypeComboBox.getSelectedIndex() == 0) missingFields.append("Account Type\n");

    
    if (missingFields.length() > 0) {
        JOptionPane.showMessageDialog(null, "Please fill out the following required fields:\n" + missingFields.toString(), "Error", JOptionPane.INFORMATION_MESSAGE);
        return;
    }

    
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String dob = sdf.format(dobDate);

    
    if (!name.matches("[a-zA-Z\\s.]+")) {
        JOptionPane.showMessageDialog(null, "Please input a valid name!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!nationality.matches("[a-zA-Z\\s]+")) {
        JOptionPane.showMessageDialog(null, "Please input a valid nationality!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!address.matches("[a-zA-Z0-9\\s.,-]+")) {
        JOptionPane.showMessageDialog(null, "Please input a valid address!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!accountNo.matches("\\d{10}")) {
        JOptionPane.showMessageDialog(null, "Account number must be exactly 10 digits!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!accountPin.matches("\\d{4}")) {
        JOptionPane.showMessageDialog(null, "Account PIN must be exactly 4 digits!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!amountdepo.matches("\\d+(\\.\\d{1,2})?")) {
        JOptionPane.showMessageDialog(null, "Please enter a valid deposit amount (e.g., 1000 or 1000.50)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    pst = con.prepareStatement("SELECT * FROM create_acc WHERE account_no = ?");
    pst.setString(1, accountNo);
    ResultSet rs = pst.executeQuery();

    if (rs.next()) {
        JOptionPane.showMessageDialog(null, "Account number already exists. Please choose a different account number.", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        
        pst = con.prepareStatement("INSERT INTO create_acc (name, dob, nationality, gender, address, account_no, account_pin, account_type, amount_deposit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        pst.setString(1, name);
        pst.setString(2, dob);
        pst.setString(3, nationality);
        pst.setString(4, gender);
        pst.setString(5, address);
        pst.setString(6, accountNo);
        pst.setString(7, accountPin);
        pst.setString(8, accountType);
        pst.setString(9, amountdepo);

        int i = pst.executeUpdate();

        if (i == 1) {
            JOptionPane.showMessageDialog(null, "Account created successfully!", "", JOptionPane.INFORMATION_MESSAGE);

            
            nameField.setText("");
            dobField.setDate(null);
            nationalityField.setText("");
            buttonGroup1.clearSelection();
            addressField.setText("");
            accountNoField.setText("");
            accountPinField.setText("");
            accountTypeComboBox.setSelectedIndex(0);
            amount.setText("");
            nameField.requestFocus();
        }
    }
} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton11ActionPerformed

    private void maleRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleRadioButtonActionPerformed
        // TODO add your handling code here:
        maleRadioButton.setActionCommand("Male");
    }//GEN-LAST:event_maleRadioButtonActionPerformed

    private void femaleRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femaleRadioButtonActionPerformed
        // TODO add your handling code here:
        femaleRadioButton.setActionCommand("Female");
    }//GEN-LAST:event_femaleRadioButtonActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
     create_acc();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
      DefaultTableModel ob = (DefaultTableModel) jTable15.getModel();
        TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
        jTable15.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search.getText()));
    }//GEN-LAST:event_searchKeyReleased

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
String No = id_no.getText();
String fname = name.getText(); 
Date dateofbirth = dob.getDate();
String nation = nationality1.getText();
String gend = (String) gender1.getSelectedItem();
String add = address.getText();

try {
    
    if (No == null || No.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a valid ID number.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!No.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(this, "Student ID should contain only numbers.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    if (fname == null || fname.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a valid name.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!fname.matches("[a-zA-Z ]+")) { 
        JOptionPane.showMessageDialog(this, "Name should only contain letters and spaces.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    if (dateofbirth == null) {
        JOptionPane.showMessageDialog(this, "Please select a valid date of birth.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    if (nation == null || nation.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a valid nationality.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!nation.matches("[a-zA-Z ]+")) { 
        JOptionPane.showMessageDialog(this, "Nationality should only contain letters and spaces.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    if (gend == null || gend.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please select a valid gender.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!gend.matches("[a-zA-Z]+")) {
        JOptionPane.showMessageDialog(this, "Gender should only contain letters.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    if (add == null || add.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a valid address.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String formattedDate = sdf.format(dateofbirth);

    
    pst = con.prepareStatement("UPDATE `create_acc` SET name=?, dob=?, nationality=?, gender=?, address=? WHERE acc_id=?");

    
    pst.setString(1, fname);
    pst.setString(2, formattedDate); 
    pst.setString(3, nation);
    pst.setString(4, gend);
    pst.setString(5, add);
    pst.setString(6, No);

   
    int rowsUpdated = pst.executeUpdate();

    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(this, "Information Successfully Updated");

        
        id_no.setText("");
        name.setText("");
        dob.setDate(null); 
        nationality1.setText("");
        gender1.setSelectedIndex(0);
        address.setText("");
    } else {
        JOptionPane.showMessageDialog(this, "Failed to update information.", "Error", JOptionPane.ERROR_MESSAGE);
    }

} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
    JOptionPane.showMessageDialog(this, "Error updating record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_updateButtonActionPerformed

    private void jTable15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable15MouseClicked
   jTable15.getSelectionModel().addListSelectionListener(e -> {
   
    if (!e.getValueIsAdjusting()) {
        int selectedRowIndex = jTable15.getSelectedRow();

        
        if (selectedRowIndex != -1) {
            try {
                String acc_no = jTable15.getValueAt(selectedRowIndex, 0).toString();
                String fullName = jTable15.getValueAt(selectedRowIndex, 1).toString();
                String dateOfBirth = jTable15.getValueAt(selectedRowIndex, 2).toString();
                String nationality = jTable15.getValueAt(selectedRowIndex, 3).toString();
                String gender = jTable15.getValueAt(selectedRowIndex, 4).toString();
                String fullAddress = jTable15.getValueAt(selectedRowIndex, 5).toString();

                
                id_no.setText(acc_no);
                name.setText(fullName);
                nationality1.setText(nationality);
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                dob.setDate(sdf.parse(dateOfBirth));
                
                gender1.setSelectedItem(gender);
                address.setText(fullAddress);

            } catch (ParseException ex) {
                Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Error parsing date: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
});

    }//GEN-LAST:event_jTable15MouseClicked

    private void amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amountActionPerformed

    private void search1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search1KeyReleased
     DefaultTableModel ob = (DefaultTableModel) jTable23.getModel();
        TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
        jTable23.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search1.getText()));
    }//GEN-LAST:event_search1KeyReleased

    private void jTable23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable23MouseClicked
    jTable23.getSelectionModel().addListSelectionListener(e -> {
    if (!e.getValueIsAdjusting()) {
        int selectedRowIndex = jTable23.getSelectedRow(); 

       
        if (selectedRowIndex != -1) {
            try {
                String acc_no = jTable23.getValueAt(selectedRowIndex, 0).toString();
                String fullName = jTable23.getValueAt(selectedRowIndex, 1).toString();
                String accountno = jTable23.getValueAt(selectedRowIndex, 2).toString(); 
                String accountpin = jTable23.getValueAt(selectedRowIndex, 3).toString(); 
                String accounttype = jTable23.getValueAt(selectedRowIndex, 4).toString();
                String amountdepo = jTable23.getValueAt(selectedRowIndex, 5).toString();

                
                id_n.setText(acc_no);
                n1.setText(fullName);
                acc1.setText(accountno);
                pin1.setText(accountpin);
                accty1.setSelectedItem(accounttype);
                bal1.setText(amountdepo);


            } catch (Exception ex) {
                Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
});
    }//GEN-LAST:event_jTable23MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
   try {
    int selectedRowIndex = jTable15.getSelectedRow();

    if (selectedRowIndex != -1) {
        
        String id = jTable15.getValueAt(selectedRowIndex, 0).toString();

        
        pst = con.prepareStatement("SELECT amount_deposit FROM create_acc WHERE acc_id=?");
        pst.setString(1, id);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            double balance = rs.getDouble("amount_deposit");

            
            if (balance == 0) {
                
                int confirmResult = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE this Account?", "", JOptionPane.YES_NO_OPTION);

                if (confirmResult == JOptionPane.YES_OPTION) {
                    
                    pst = con.prepareStatement("DELETE FROM create_acc WHERE acc_id=?");
                    pst.setString(1, id);
                    int deleteCount = pst.executeUpdate();

                    if (deleteCount == 1) {
                        JOptionPane.showMessageDialog(null, "Account has been deleted!!.", "", JOptionPane.INFORMATION_MESSAGE);

                       
                        DefaultTableModel model = (DefaultTableModel) jTable15.getModel();
                        model.removeRow(selectedRowIndex);
                    }
                }
            } else {
                
                JOptionPane.showMessageDialog(null, "You have a balance in your Account, cannot delete the account.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "", JOptionPane.WARNING_MESSAGE);
    }

} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
      try {
    int selectedRowIndex = jTable23.getSelectedRow();

    if (selectedRowIndex != -1) {
       
        String id = jTable23.getValueAt(selectedRowIndex, 0).toString();

        
        pst = con.prepareStatement("SELECT amount_deposit FROM create_acc WHERE acc_id=?");
        pst.setString(1, id);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            double balance = rs.getDouble("amount_deposit"); 

            
            if (balance == 0) {
                
                int confirmResult = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE this Account?", "", JOptionPane.YES_NO_OPTION);

                if (confirmResult == JOptionPane.YES_OPTION) {
                    
                    pst = con.prepareStatement("DELETE FROM create_acc WHERE acc_id=?");
                    pst.setString(1, id);
                    int deleteCount = pst.executeUpdate();

                    if (deleteCount == 1) {
                        JOptionPane.showMessageDialog(null, "Account has been deleted!!.", "", JOptionPane.INFORMATION_MESSAGE);

                        
                        DefaultTableModel model = (DefaultTableModel) jTable23.getModel();
                        model.removeRow(selectedRowIndex);
                    }
                }
            } else {
                
                JOptionPane.showMessageDialog(null, "You have a balance in your Account, cannot delete the account.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "", JOptionPane.WARNING_MESSAGE);
    }

} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
String accId = id_n.getText(); 
String fullName = n1.getText();
String accNumber = acc1.getText();
String accPin = pin1.getText(); 
String accType = accty1.getSelectedItem().toString().trim();
String balance = bal1.getText();

try {
   
    if (accId.isEmpty() || fullName.isEmpty() || accNumber.isEmpty() || accPin.isEmpty() || accType.isEmpty() || balance.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    if (!accId.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(this, "Account ID must be numeric.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    if (!accNumber.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(this, "Account Number must be numeric.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

   
    if (!accPin.matches("[0-9]+") || accPin.length() != 4) {
        JOptionPane.showMessageDialog(this, "Account PIN must be a 4-digit number.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    if (!fullName.matches("[a-zA-Z ]+")) {
        JOptionPane.showMessageDialog(this, "Name should only contain letters and spaces.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    if (!balance.matches("\\d+(\\.\\d{1,2})?")) {
        JOptionPane.showMessageDialog(this, "Balance must be a numeric value with up to two decimal places.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    pst = con.prepareStatement("UPDATE `create_acc` SET name=?, account_no=?, account_pin=?, account_type=?, amount_deposit=? WHERE acc_id=?");

    
    pst.setString(1, fullName);
    pst.setString(2, accNumber);
    pst.setString(3, accPin);
    pst.setString(4, accType);
    pst.setDouble(5, Double.parseDouble(balance));
    pst.setString(6, accId);

    
    int rowsUpdated = pst.executeUpdate();

    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(this, "Account Information Successfully Updated");

        
        id_n.setText("");
        n1.setText("");
        acc1.setText("");
        pin1.setText("");
        accty1.setSelectedIndex(0);
        bal1.setText("");
    } else {
        JOptionPane.showMessageDialog(this, "Failed to update account information", "Error", JOptionPane.ERROR_MESSAGE);
    }

} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
    JOptionPane.showMessageDialog(this, "Error updating record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
     user_info();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
     deposite_histo();
    }//GEN-LAST:event_jButton25ActionPerformed

    private void search81MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search81MouseClicked
     
    }//GEN-LAST:event_search81MouseClicked

    private void search81KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search81KeyReleased
    DefaultTableModel ob = (DefaultTableModel) jTable2.getModel();
        TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
        jTable2.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search81.getText()));
    }//GEN-LAST:event_search81KeyReleased

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
    try {
    int selectedRowIndex = jTable2.getSelectedRow();
    
 
    if (selectedRowIndex != -1) {
        String id = jTable2.getValueAt(selectedRowIndex, 0).toString();
        
        int confirmResult = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE this History!?", "", JOptionPane.YES_NO_OPTION);
        
        if (confirmResult == JOptionPane.YES_OPTION) {
          
            pst = con.prepareStatement("DELETE FROM deposit_histo WHERE depo_id=?");
            pst.setString(1, id);
            
            
            int deleteCount = pst.executeUpdate();
            
           
            if (deleteCount == 1) {
                JOptionPane.showMessageDialog(null, "Deposite History  has been deleted!!.", "", JOptionPane.INFORMATION_MESSAGE);
                
               
                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.removeRow(selectedRowIndex);
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "", JOptionPane.WARNING_MESSAGE);
    }
    
} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton13ActionPerformed

    private void search82KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search82KeyReleased
     DefaultTableModel ob = (DefaultTableModel) jTable21.getModel();
        TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
        jTable21.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search82.getText()));
    }//GEN-LAST:event_search82KeyReleased

    private void search83KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search83KeyReleased
     DefaultTableModel ob = (DefaultTableModel) jTable5.getModel();
        TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
        jTable5.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search83.getText()));
    }//GEN-LAST:event_search83KeyReleased

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
    withdraw_histo();
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
     try {
    int selectedRowIndex = jTable21.getSelectedRow();
    
 
    if (selectedRowIndex != -1) {
        String id = jTable21.getValueAt(selectedRowIndex, 0).toString();
        
        int confirmResult = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE this History!?", "", JOptionPane.YES_NO_OPTION);
        
        if (confirmResult == JOptionPane.YES_OPTION) {
          
            pst = con.prepareStatement("DELETE FROM withdraw_histo WHERE withdraw_id=?");
            pst.setString(1, id);
            
            
            int deleteCount = pst.executeUpdate();
            
           
            if (deleteCount == 1) {
                JOptionPane.showMessageDialog(null, "Withdraw History  has been deleted!!.", "", JOptionPane.INFORMATION_MESSAGE);
                
               
                DefaultTableModel model = (DefaultTableModel) jTable21.getModel();
                model.removeRow(selectedRowIndex);
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "", JOptionPane.WARNING_MESSAGE);
    }
    
} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
     try {
    int selectedRowIndex = jTable5.getSelectedRow();
    
 
    if (selectedRowIndex != -1) {
        String id = jTable5.getValueAt(selectedRowIndex, 0).toString();
        
        int confirmResult = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE this History!?", "", JOptionPane.YES_NO_OPTION);
        
        if (confirmResult == JOptionPane.YES_OPTION) {
          
            pst = con.prepareStatement("DELETE FROM transfer_histo WHERE trans_id=?");
            pst.setString(1, id);
            
            
            int deleteCount = pst.executeUpdate();
            
           
            if (deleteCount == 1) {
                JOptionPane.showMessageDialog(null, "Transfer History  has been deleted!!.", "", JOptionPane.INFORMATION_MESSAGE);
                
               
                DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
                model.removeRow(selectedRowIndex);
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "", JOptionPane.WARNING_MESSAGE);
    }
    
} catch (SQLException ex) {
    Logger.getLogger(admin_dashboard.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
    transfer_histo();
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        id_n.setText("");
        n1.setText("");
        acc1.setText("");
        pin1.setText("");
        accty1.setSelectedIndex(0);
        bal1.setText("");
    }//GEN-LAST:event_jButton28ActionPerformed

    private void updateButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButton1ActionPerformed
        id_no.setText("");
        name.setText("");
        dob.setDate(null);
        nationality1.setText("");
        gender1.setSelectedIndex(0);
        address.setText("");
    }//GEN-LAST:event_updateButton1ActionPerformed

    private void accountNoFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_accountNoFieldKeyTyped
      if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_accountNoFieldKeyTyped

    private void accountPinFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_accountPinFieldKeyTyped
      if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_accountPinFieldKeyTyped

    private void amountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountKeyTyped
     if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_amountKeyTyped

    private void acc1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_acc1KeyTyped
     if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_acc1KeyTyped

    private void pin1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pin1KeyTyped
     if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_pin1KeyTyped

    private void bal1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bal1KeyTyped
      if(!Character.isDigit(evt.getKeyChar()))
     {
         evt.consume();
     }
    }//GEN-LAST:event_bal1KeyTyped

    private void nameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameKeyTyped
    if(!Character.isAlphabetic(evt.getKeyChar()))
        {
            evt.consume();
        }
    }//GEN-LAST:event_nameKeyTyped

    private void nationality1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nationality1KeyTyped
     if(!Character.isAlphabetic(evt.getKeyChar()))
        {
            evt.consume();
        }
    }//GEN-LAST:event_nationality1KeyTyped

    private void n1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_n1KeyTyped
    if(!Character.isAlphabetic(evt.getKeyChar()))
        {
            evt.consume();
        }
    }//GEN-LAST:event_n1KeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField acc1;
    private javax.swing.JTextField accountNoField;
    private javax.swing.JTextField accountPinField;
    private javax.swing.JComboBox<String> accountTypeComboBox;
    private javax.swing.JComboBox<String> accty1;
    private javax.swing.JTextField address;
    private javax.swing.JTextField addressField;
    private javax.swing.JTextField amount;
    private javax.swing.JTextField bal1;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.toedter.calendar.JDateChooser dob;
    private com.toedter.calendar.JDateChooser dobField;
    private javax.swing.JRadioButton femaleRadioButton;
    private javax.swing.JComboBox<String> gender1;
    private javax.swing.JTextField id_n;
    private javax.swing.JTextField id_no;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane12;
    private javax.swing.JTabbedPane jTabbedPane13;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable15;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable21;
    private javax.swing.JTable jTable23;
    private javax.swing.JTable jTable5;
    private javax.swing.JRadioButton maleRadioButton;
    private javax.swing.JTextField n1;
    private javax.swing.JTextField name;
    private javax.swing.JTextField nameField;
    private javax.swing.JTextField nationality1;
    private javax.swing.JTextField nationalityField;
    private javax.swing.JTextField pin1;
    private javax.swing.JTextField search;
    private javax.swing.JTextField search1;
    private javax.swing.JTextField search81;
    private javax.swing.JTextField search82;
    private javax.swing.JTextField search83;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton updateButton1;
    // End of variables declaration//GEN-END:variables
}
